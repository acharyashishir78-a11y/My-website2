import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import Database from 'better-sqlite3';
import cors from 'cors';
import crypto from 'crypto';

const db = new Database('database.sqlite');

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    videoUrl TEXT,
    imageUrl TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

const insertProduct = db.prepare('INSERT INTO products (id, title, description, category, videoUrl, imageUrl) VALUES (@id, @title, @description, @category, @videoUrl, @imageUrl)');
const getProducts = db.prepare('SELECT * FROM products ORDER BY createdAt DESC');
const deleteProduct = db.prepare('DELETE FROM products WHERE id = ?');

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // API Routes
  app.get('/api/products', (req, res) => {
    try {
      const products = getProducts.all();
      res.json({ success: true, products });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Failed to fetch products' });
    }
  });

  app.post('/api/products', async (req, res) => {
    const { category, videoUrl } = req.body;
    let title = "Tech Showcase Video";
    let description = "Description is currently unavailable.";
    const imageUrl = null;

    if (!videoUrl) {
      return res.status(400).json({ success: false, error: 'Video URL is required' });
    }

    try {
      if (videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be')) {
        try {
          const oembedRes = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(videoUrl)}&format=json`);
          if (oembedRes.ok) {
            const odata = await oembedRes.json();
            title = odata.title || title;
          }
        } catch(e) {}

        try {
          const ytRes = await fetch(videoUrl, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
          });
          const html = await ytRes.text();
          const descMatch = html.match(/"shortDescription":"(.*?)(?<!\\)"/);
          if (descMatch && descMatch[1]) {
            description = descMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\\\/g, '\\');
          } else {
            const ogMatch = html.match(/<meta property="og:description" content="([^"]+)">/);
            if (ogMatch) description = ogMatch[1];
          }
        } catch(e) {}
      }

      const id = crypto.randomUUID();
      insertProduct.run({
        id,
        title,
        description,
        category,
        videoUrl: videoUrl,
        imageUrl: imageUrl
      });
      res.json({ success: true, product: { id, title, description, category, videoUrl, imageUrl } });
    } catch (error) {
      console.error(error);
      res.status(500).json({ success: false, error: 'Failed to add product' });
    }
  });

  app.delete('/api/products/:id', (req, res) => {
    try {
      deleteProduct.run(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Failed to delete product' });
    }
  });

  // Vite Integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
