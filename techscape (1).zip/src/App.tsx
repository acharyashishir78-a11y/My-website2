import React, { useState, useEffect, useMemo } from 'react';
import { Routes, Route, Link, useNavigate, useParams } from 'react-router-dom';
import { Plus, X, Laptop, Tv, Headphones, Monitor, Sparkle, Cable, Cpu, PlayCircle, Settings, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Category = 'Laptop' | 'TV' | 'Audio' | 'Accessories' | 'Other';
const CATEGORIES: Category[] = ['Laptop', 'TV', 'Audio', 'Accessories', 'Other'];

interface Product {
  id: string;
  title: string;
  description: string;
  category: Category;
  videoUrl?: string;
  imageUrl?: string;
}

const CategoryIcon = ({ category, className }: { category: Category, className?: string }) => {
  switch (category) {
    case 'Laptop': return <Laptop className={className} />;
    case 'TV': return <Tv className={className} />;
    case 'Audio': return <Headphones className={className} />;
    case 'Accessories': return <Cable className={className} />;
    default: return <Cpu className={className} />;
  }
};

const Thumbnail = ({ url }: { url: string }) => {
  const isYouTube = url.includes('youtube.com') || url.includes('youtu.be');
  
  if (isYouTube) {
    const videoId = url.split('v=')[1]?.split('&')[0] || url.split('youtu.be/')[1]?.split('?')[0] || '';
    return (
      <>
        <img 
          src={`https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`} 
          onError={(e) => { e.currentTarget.src = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`; }}
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          alt="Video Thumbnail"
        />
        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-[11px] px-2 py-0.5 rounded opacity-90 font-medium tracking-wide">
          WATCH
        </div>
      </>
    );
  }
  
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-slate-900 border border-slate-200">
      <PlayCircle size={36} className="text-slate-500 opacity-50" />
    </div>
  );
};

function ConsumerView({ products }: { products: Product[] }) {
  const [activeFilter, setActiveFilter] = useState<Category | 'All'>('All');

  const filteredProducts = useMemo(() => {
    if (activeFilter === 'All') return products;
    return products.filter(p => p.category === activeFilter);
  }, [products, activeFilter]);

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 selection:bg-blue-200">
      <header className="px-4 md:px-8 py-3 bg-white border-b border-slate-200 flex justify-between items-center sticky top-0 z-20 shadow-sm">
        <Link to="/" className="flex items-center gap-2">
          <Sparkle className="text-blue-600" size={24} />
          <span className="font-[family-name:var(--font-display)] text-2xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            TechScape
          </span>
        </Link>
        <Link 
          to="/admin"
          className="rounded-full px-5 py-2 bg-slate-100 text-slate-700 font-medium hover:bg-slate-200 transition-colors text-sm flex items-center gap-2"
        >
          <Settings size={16} />
          <span className="hidden sm:inline">Backend / Admin</span>
        </Link>
      </header>

      <main className="max-w-[1800px] mx-auto p-4 md:p-8">
        {/* Filter Bar */}
        <div className="mb-8 flex overflow-x-auto pb-4 hide-scrollbar">
          <div className="flex gap-3">
            <button
              onClick={() => setActiveFilter('All')}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition-all font-medium text-sm ${
                activeFilter === 'All'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All
            </button>
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveFilter(cat)}
                className={`px-4 py-2 rounded-lg whitespace-nowrap transition-all font-medium text-sm flex items-center gap-2 ${
                  activeFilter === cat
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <CategoryIcon category={cat} className="w-4 h-4" />
                {cat}
              </button>
            ))}
          </div>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="text-center py-32 bg-white rounded-3xl border border-dashed border-slate-300 shadow-sm">
            <div className="w-16 h-16 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Sparkle size={32} />
            </div>
            <p className="font-[family-name:var(--font-display)] text-2xl font-semibold text-slate-800 mb-2">No videos found</p>
            <p className="text-slate-500 text-lg">
              {activeFilter !== 'All' 
                ? `There are no video showcases in the ${activeFilter} category yet.` 
                : 'The tech collection is waiting for its first video.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-x-4 gap-y-10">
            <AnimatePresence mode="popLayout">
              {filteredProducts.map((product, index) => (
                <motion.article 
                  key={product.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 20 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className="flex flex-col group"
                >
                  <Link to={`/watch/${product.id}`} className="block relative focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-xl">
                    <div className="w-full aspect-video rounded-xl overflow-hidden mb-3 bg-slate-200 relative shadow-sm border border-slate-200/50">
                      <Thumbnail url={product.videoUrl || ''} />
                    </div>
                  </Link>

                  <div className="flex gap-3 px-1">
                    <div className="flex-shrink-0 mt-1">
                      <div className="w-9 h-9 rounded-full bg-slate-200/70 flex items-center justify-center text-slate-600">
                        <CategoryIcon category={product.category} className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="flex-grow overflow-hidden">
                      <Link to={`/watch/${product.id}`} className="block group-hover:text-blue-600 transition-colors focus:outline-none">
                        <h3 className="font-semibold text-slate-900 text-base leading-snug mb-1 line-clamp-2" title={product.title}>
                          {product.title}
                        </h3>
                      </Link>
                      <div className="text-slate-500 text-sm font-medium">
                        TechScape Curated
                      </div>
                      <div className="text-slate-500 text-xs mt-1">
                        {product.category}
                      </div>
                    </div>
                  </div>
                </motion.article>
              ))}
            </AnimatePresence>
          </div>
        )}
      </main>
    </div>
  );
}

function WatchView({ products }: { products: Product[] }) {
  const { id } = useParams();
  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Video Not Found</h2>
          <Link to="/" className="text-blue-600 hover:underline">Return to Home</Link>
        </div>
      </div>
    );
  }

  const isYouTube = product.videoUrl?.includes('youtube.com') || product.videoUrl?.includes('youtu.be');
  let videoId = '';
  if (isYouTube && product.videoUrl) {
    videoId = product.videoUrl.split('v=')[1]?.split('&')[0] || product.videoUrl.split('youtu.be/')[1]?.split('?')[0];
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <header className="px-4 md:px-8 py-3 bg-white border-b border-slate-200 flex justify-between items-center sticky top-0 z-20 shadow-sm">
        <Link to="/" className="flex items-center gap-2">
          <Sparkle className="text-blue-600" size={24} />
          <span className="font-[family-name:var(--font-display)] text-2xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            TechScape
          </span>
        </Link>
      </header>
      
      <div className="max-w-[1800px] mx-auto w-full flex flex-col lg:flex-row gap-6 p-4 md:p-6 lg:p-8">
        <div className="w-full lg:w-[70%] xl:w-[75%] flex-shrink-0">
          <div className="w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl shadow-blue-900/5 mb-5 border border-slate-200">
            {isYouTube ? (
              <iframe
                className="w-full h-full"
                src={`https://www.youtube.com/embed/${videoId}?autoplay=1&modestbranding=1&rel=0&playsinline=1`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            ) : product.videoUrl ? (
              <video src={product.videoUrl} controls autoPlay className="w-full h-full object-contain bg-black" />
            ) : (
               <div className="w-full h-full flex items-center justify-center text-slate-500">No video URL available</div>
            )}
          </div>
          
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 mb-3">{product.title}</h1>
          
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center text-slate-700">
               <CategoryIcon category={product.category} className="w-6 h-6" />
            </div>
            <div>
              <p className="font-semibold text-slate-900">TechScape Curated</p>
              <p className="text-sm text-slate-500">{product.category}</p>
            </div>
          </div>
          
          <div className="bg-slate-100/80 rounded-2xl p-4 md:p-5 text-sm md:text-base text-slate-800 whitespace-pre-line leading-relaxed shadow-sm border border-slate-200">
            <span className="font-semibold block mb-2">Description</span>
            {product.description}
          </div>
        </div>

        {/* Up Next Sidebar */}
        <div className="w-full lg:w-[30%] xl:w-[25%]">
          <h3 className="font-bold text-slate-900 mb-4">Up Next</h3>
          <div className="flex flex-col gap-4">
            {products.filter(p => p.id !== product.id).map(p => (
              <Link to={`/watch/${p.id}`} key={p.id} className="flex gap-3 group">
                <div className="w-[160px] flex-shrink-0 rounded-xl overflow-hidden relative aspect-video bg-slate-200 border border-slate-200 group-hover:shadow-md transition-shadow">
                   <Thumbnail url={p.videoUrl || ''} />
                </div>
                <div className="flex-grow py-1 pr-2">
                  <h4 className="text-sm font-semibold text-slate-900 line-clamp-2 group-hover:text-blue-600 transition-colors leading-snug mb-1">
                    {p.title}
                  </h4>
                  <p className="text-xs text-slate-500 mb-1">TechScape Curated</p>
                  <p className="text-[11px] text-slate-400 font-medium">{p.category}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function AdminView({ products, fetchProducts }: { products: Product[], fetchProducts: () => void }) {
  const [newCategory, setNewCategory] = useState<Category>('Laptop');
  const [newVideoUrl, setNewVideoUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVideoUrl.trim()) return;

    setIsSubmitting(true);
    try {
      await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category: newCategory,
          videoUrl: newVideoUrl.trim()
        }),
      });
      
      setNewCategory('Laptop');
      setNewVideoUrl('');
      fetchProducts();
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/products/${id}`, { method: 'DELETE' });
      fetchProducts();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="min-h-screen p-6 md:p-12 lg:p-24 bg-slate-900 text-slate-50 selection:bg-blue-500/30">
      <header className="max-w-5xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6 border-b border-slate-800 pb-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Settings className="text-blue-400" size={24} />
            <h1 className="font-[family-name:var(--font-display)] text-3xl font-bold tracking-tight">
              Backend Content Manager
            </h1>
          </div>
          <p className="text-slate-400">Add or remove tech video showcases for consumers.</p>
        </div>
        <Link 
          to="/"
          className="rounded-full px-6 py-2.5 bg-slate-800 text-white font-medium hover:bg-slate-700 transition-colors border border-slate-700"
        >
          View Consumer Site
        </Link>
      </header>

      <main className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-1">
          <div className="bg-slate-800 p-8 rounded-3xl border border-slate-700 sticky top-12">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Plus size={20} className="text-blue-400" />
              Publish New Gadget
            </h2>
            
            <form onSubmit={handleAdd} className="space-y-6">
              <div className="bg-blue-500/10 border border-blue-500/20 text-blue-300 p-4 rounded-xl text-sm leading-relaxed">
                <Sparkle className="inline mr-2" size={16} />
                Just paste a YouTube URL. The title and description will be automatically extracted from the video!
              </div>

              <div>
                <label htmlFor="videoUrl" className="block text-sm font-medium text-slate-300 mb-2">YouTube Video URL</label>
                <input
                  id="videoUrl"
                  type="url"
                  value={newVideoUrl}
                  onChange={(e) => setNewVideoUrl(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
                  placeholder="https://youtube.com/watch?v=..."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Category</label>
                <div className="grid grid-cols-2 gap-2">
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setNewCategory(cat)}
                      className={`px-3 py-2 rounded-lg flex items-center gap-2 text-sm border ${
                        newCategory === cat 
                        ? 'bg-blue-600 border-blue-500 text-white' 
                        : 'bg-slate-900 border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      } transition-colors`}
                    >
                      <CategoryIcon category={cat} className="w-4 h-4" />
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <button 
                type="submit" 
                disabled={!newVideoUrl.trim() || isSubmitting}
                className="w-full py-3 mt-4 rounded-xl bg-blue-600 text-white font-semibold hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-lg shadow-blue-600/30"
              >
                {isSubmitting ? 'Extracting & Publishing...' : 'Extract Meta & Publish'}
              </button>
            </form>
          </div>
        </div>

        <div className="lg:col-span-2">
          <h2 className="text-xl font-bold mb-6 text-slate-300">Managed Content ({products.length})</h2>
          
          <div className="space-y-4">
            {products.length === 0 ? (
              <div className="text-center py-12 bg-slate-800/50 rounded-2xl border border-dashed border-slate-700">
                <p className="text-slate-500">No content published yet.</p>
              </div>
            ) : (
              products.map(product => (
                <div key={product.id} className="bg-slate-800 p-6 rounded-2xl border border-slate-700 flex gap-6 items-start">
                  <div className="flex-grow overflow-hidden">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs font-medium px-2.5 py-1 rounded bg-slate-900 text-blue-400">
                        {product.category}
                      </span>
                      {product.videoUrl && (
                        <span className="text-xs font-medium px-2.5 py-1 rounded bg-slate-900 text-emerald-400 flex items-center gap-1">
                          <PlayCircle size={12} /> Video Attached
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-bold text-white mb-1 truncate">{product.title}</h3>
                    <p className="text-sm text-slate-400 line-clamp-2">{product.description}</p>
                    {product.videoUrl && (
                      <p className="text-xs text-slate-500 mt-2 truncate w-full">{product.videoUrl}</p>
                    )}
                  </div>
                  <button 
                    onClick={() => handleDelete(product.id)}
                    className="p-3 bg-slate-900 rounded-xl text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors flex-shrink-0"
                    title="Delete item"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/products');
      const data = await res.json();
      if (data.success) {
        setProducts(data.products);
      }
    } catch (error) {
      console.error("Failed to fetch products:", error);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <Routes>
      <Route path="/" element={<ConsumerView products={products} />} />
      <Route path="/watch/:id" element={<WatchView products={products} />} />
      <Route path="/admin" element={<AdminView products={products} fetchProducts={fetchProducts} />} />
    </Routes>
  );
}

